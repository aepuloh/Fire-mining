// api/deposit.js
import { readDB, writeDB, jsonResponse, getBody, getUserIdFromReq } from './_utils.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return jsonResponse(res, { status: 'error', message: 'POST required' }, 405);
  }

  let userId = getUserIdFromReq(req);
  const body = await getBody(req);
  userId = userId || body.userId || body.user_id || body.telegram_id;

  if (!userId) return jsonResponse(res, { status: 'error', message: 'userId required' }, 400);

  const amount = Number(body.amount || 0);
  if (amount <= 0) return jsonResponse(res, { status: 'error', message: 'Invalid amount' }, 400);

  const db = readDB();
  if (!db.users[userId]) {
    db.users[userId] = { username: null, kot_balance: 0, usdt_balance: 0, wallet: null, watched: [] };
  }

  const user = db.users[userId];
  user.usdt_balance += amount;

  db.transactions = db.transactions || [];
  db.transactions.push({
    id: Date.now(),
    type: 'deposit',
    userId,
    amount_usdt: amount,
    created_at: new Date().toISOString(),
    status: 'completed'
  });

  try { writeDB(db); } catch {}

  return jsonResponse(res, { status: 'ok', deposited: amount, usdt_balance: user.usdt_balance });
}