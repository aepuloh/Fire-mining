// api/referral.js
import { readDB, writeDB, jsonResponse, getBody, getUserIdFromReq } from './_utils.js';

export default async function handler(req, res) {
  let userId = getUserIdFromReq(req);
  let body = {};

  if (req.method === 'POST') {
    body = await getBody(req);
    userId = userId || body.userId || body.user_id || body.telegram_id;
  }

  const refId = body.ref || body.refId || (() => {
    try {
      const url = new URL('http://example.com' + (req.url || ''));
      return url.searchParams.get('ref');
    } catch {
      return null;
    }
  })();

  if (!userId) return jsonResponse(res, { status: 'error', message: 'userId required' }, 400);
  if (!refId) return jsonResponse(res, { status: 'error', message: 'Referral ID required' }, 400);
  if (userId === refId) return jsonResponse(res, { status: 'error', message: 'Cannot refer yourself' }, 400);

  const db = readDB();
  db.users = db.users || {};
  db.referrals = db.referrals || [];

  if (!db.users[userId]) {
    db.users[userId] = { username: null, kot_balance: 0, usdt_balance: 0, wallet: null, watched: [] };
  }
  if (!db.users[refId]) {
    db.users[refId] = { username: null, kot_balance: 0, usdt_balance: 0, wallet: null, watched: [] };
  }

  // Cek kalau referral sudah pernah dipakai
  if (db.referrals.find(r => r.userId === userId)) {
    return jsonResponse(res, { status: 'already', message: 'Referral already claimed' });
  }

  // Simpan referral
  db.referrals.push({ userId, refId, created_at: new Date().toISOString() });

  // Reward ke referrer
  const reward = 5; // contoh reward referral dalam KOT
  db.users[refId].kot_balance += reward;

  db.transactions = db.transactions || [];
  db.transactions.push({
    id: Date.now(),
    type: 'referral_reward',
    userId: refId,
    referred_user: userId,
    amount_kot: reward,
    created_at: new Date().toISOString()
  });

  try { writeDB(db); } catch {}

  return jsonResponse(res, { status: 'ok', referrer: refId, reward });
}