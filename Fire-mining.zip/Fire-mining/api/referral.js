// api/referral.js
const { readDB, writeDB, jsonResponse, getBody } = require('./_utils');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return jsonResponse(res, { status:'error', message:'Use POST' }, 405);
  const body = await getBody(req);
  const referrer = String(body.referrer_id || body.referrer || body.referrerId || '');
  const newUser = String(body.new_user_id || body.new_user || body.newUser || '');

  if (!referrer || !newUser) return jsonResponse(res, { status:'error', message:'referrer_id & new_user_id required' }, 400);

  const db = readDB();
  db.referrals = db.referrals || [];
  // prevent duplicate
  const exists = db.referrals.find(r => r.referrer === referrer && r.new_user === newUser);
  if (exists) return jsonResponse(res, { status:'already', message:'referral exists' });

  db.referrals.push({ referrer, new_user: newUser, at: new Date().toISOString() });
  db.users = db.users || {};
  db.users[referrer] = db.users[referrer] || { kot_balance:0, usdt_balance:0, watched: [] };
  // give small referral bonus
  const bonus = 1;
  db.users[referrer].kot_balance = (Number(db.users[referrer].kot_balance || 0) + bonus);

  // record transaction
  db.transactions = db.transactions || [];
  db.transactions.push({ id: Date.now(), type: 'referral_bonus', referrer, new_user: newUser, amount_kot: bonus, created_at: new Date().toISOString() });

  try { writeDB(db); } catch(e){}

  return jsonResponse(res, { status:'ok', bonus });
};