Fire-mining — watch-to-earn starter (Vercel + Telegram)

Steps:
1. Copy files ke HP/PC sesuai struktur:
   - public/index.html
   - api/_utils.js
   - api/reward.js
   - api/balance.js
   - api/referral.js
   - api/withdraw.js
   - db.json, package.json, vercel.json, .env.example, bot.py, README.md

2. Buat repo GitHub, push semua file.

3. Deploy ke Vercel:
   - Hubungkan repo, deploy.
   - Pastikan file db.json ada di root (untuk testing). Note: pada serverless, file-system ephemeral — untuk penggunaan real production, gunakan DB persistent (Postgres / managed DB).

4. Jalankan bot Telegram (bot.py) di VPS/termux/laptop:
   - export TELE_TOKEN dan BACKEND_URL lalu `python bot.py`.

CATATAN IMPORTANT:
- Endpoint withdraw saat ini hanya mencatat transaksi (mock). Untuk kirim USDT sungguhan butuh integrasi exchange/wallet API & KYC/security.
- File `db.json` sederhana dan cocok untuk uji coba. Untuk produksi migrasikan ke database nyata.