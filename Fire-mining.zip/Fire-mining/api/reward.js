// api/reward.js
import { readDB, writeDB, jsonResponse, getBody, getUserIdFromReq } from './_utils.js';

export default async function handler(req, res) {
  // Ambil userId dari query atau body
  let userId = getUserIdFromReq(req);
  let body = {};

  if (req.method === 'POST') {
    body = await getBody(req);
    userId = userId || (body.userId || body.user_id || body.telegram_id || body.telegramId);
  } else {
    try {
      const url = new URL('http://example.com' + (req.url || ''));
      if (!userId) {
        userId = url.searchParams.get('userId') || url.searchParams.get('telegram_id');
      }
    } catch (e) { }
  }

  const adId =
    body.ad_id ||
    body.adId ||
    (() => {
      try {
        const url = new URL('http://example.com' + (req.url || ''));
        return url.searchParams.get('ad_id') || url.searchParams.get('adId') || '1';
      } catch (e) {
        return '1';
      }
    })();

  if (!userId) {
    return jsonResponse(res, { status: 'error', message: 'userId required' }, 400);
  }

  const db = readDB();
  db.users = db.users || {};
  db.ads = db.ads || { "1": { id: 1, reward: 1 } };

  if (!db.users[userId]) {
    db.users[userId] = { username: null, kot_balance: 0, usdt_balance: 0, wallet: null, watched: [] };
  }

  const user = db.users[userId];
  user.watched = user.watched || [];

  if (user.watched.includes(String(adId))) {
    return jsonResponse(res, { status: 'already', message: 'Ad already watched' });
  }

  const ad = db.ads[String(adId)] || { reward: 1 };
  const reward = Number(ad.reward || 1);

  user.kot_balance = Number(user.kot_balance || 0) + reward;
  user.watched.push(String(adId));

  // Log transaksi
  db.transactions = db.transactions || [];
  db.transactions.push({
    id: Date.now(),
    type: 'reward',
    userId,
    adId: String(adId),
    amount_kot: reward,
    created_at: new Date().toISOString()
  });

  try { writeDB(db); } catch (e) { /* ignore write error */ }

  return jsonResponse(res, { status: 'ok', reward });
}