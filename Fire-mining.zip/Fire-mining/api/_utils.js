// api/_utils.js
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = path.join(process.cwd(), 'db.json');

export function readDB() {
  try {
    const raw = fs.readFileSync(DB_FILE, 'utf8');
    return JSON.parse(raw);
  } catch (e) {
    // if file missing or broken, return empty structure
    return { users: {}, ads: { "1": { id: 1, reward: 1 } }, referrals: [], transactions: [] };
  }
}

export function writeDB(db) {
  fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), 'utf8');
}

export function jsonResponse(res, data, status = 200) {
  res.statusCode = status;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(data));
}

export async function getBody(req) {
  return new Promise((resolve, reject) => {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      if (!body) return resolve({});
      try { resolve(JSON.parse(body)); }
      catch (e) {
        try {
          const params = new URLSearchParams(body);
          const obj = {};
          for (const [k, v] of params) obj[k] = v;
          resolve(obj);
        } catch {
          resolve({});
        }
      }
    });
    req.on('error', reject);
  });
}

export function getUserIdFromReq(req) {
  try {
    const url = req.url || '';
    const u = new URL('http://example.com' + url);
    const q =
      u.searchParams.get('userId') ||
      u.searchParams.get('telegram_id') ||
      u.searchParams.get('telegramId');
    if (q) return String(q);
  } catch (e) { }
  if (req.query && (req.query.userId || req.query.telegram_id)) {
    return String(req.query.userId || req.query.telegram_id);
  }
  return null;
}