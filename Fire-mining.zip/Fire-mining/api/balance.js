// api/balance.js
const { readDB, jsonResponse, getUserIdFromReq } = require('./_utils');

module.exports = (req, res) => {
  const userId = getUserIdFromReq(req);
  if (!userId) return jsonResponse(res, { status:'error', message: 'userId required' }, 400);

  const db = readDB();
  const user = db.users && db.users[userId];
  if (!user) {
    // auto create user with zero balances
    db.users = db.users || {};
    db.users[userId] = { username: null, kot_balance: 0, usdt_balance: 0, wallet: null, watched: [] };
    // write back so test persists in repo (works for local/fs; ephemeral on Vercel)
    try { require('fs').writeFileSync('db.json', JSON.stringify(db, null,2)); } catch(e){}
    return jsonResponse(res, { status:'ok', kot_balance: 0, usdt_balance: 0 });
  }

  return jsonResponse(res, { status:'ok', kot_balance: Number(user.kot_balance||0), usdt_balance: Number(user.usdt_balance||0) });
};