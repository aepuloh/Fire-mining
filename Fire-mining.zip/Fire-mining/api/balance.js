// api/balance.js
import { readDB, jsonResponse, getUserIdFromReq } from './_utils.js';
import fs from 'fs';

export default function handler(req, res) {
  const userId = getUserIdFromReq(req);
  if (!userId) {
    return jsonResponse(res, { status: 'error', message: 'userId required' }, 400);
  }

  const db = readDB();
  const user = db.users && db.users[userId];

  if (!user) {
    // Auto create user
    db.users = db.users || {};
    db.users[userId] = { username: null, kot_balance: 0, usdt_balance: 0, wallet: null, watched: [] };

    try {
      fs.writeFileSync('db.json', JSON.stringify(db, null, 2));
    } catch (e) { /* ignore in Vercel */ }

    return jsonResponse(res, { status: 'ok', kot_balance: 0, usdt_balance: 0 });
  }

  return jsonResponse(res, {
    status: 'ok',
    kot_balance: Number(user.kot_balance || 0),
    usdt_balance: Number(user.usdt_balance || 0)
  });
}