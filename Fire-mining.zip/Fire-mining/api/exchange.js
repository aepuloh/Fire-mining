// api/exchange.js
const { readDB, writeDB, jsonResponse, getBody } = require('./_utils');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return jsonResponse(res, { status:'error', message:'Use POST' }, 405);
  const body = await getBody(req);
  const userId = String(body.userId || body.userId || body.user || '');
  const kotAmount = Number(body.kot_amount || body.kotAmount || 0);
  if (!userId || kotAmount <= 0) return jsonResponse(res, { status:'error', message:'userId and kot_amount required' }, 400);

  const rate = Number(process.env.EXCHANGE_RATE || process.env.RATE || 1000); // default 1000 KOT = 1 USDT
  const usdt = kotAmount / rate;

  const db = readDB();
  db.users = db.users || {};
  const user = db.users[userId];
  if (!user) return jsonResponse(res, { status:'error', message:'user not found' }, 404);

  if ((Number(user.kot_balance || 0)) < kotAmount) return jsonResponse(res, { status:'error', message:'insufficient KOT' }, 400);

  user.kot_balance = Number(user.kot_balance) - kotAmount;
  user.usdt_balance = Number(user.usdt_balance || 0) + usdt;

  db.transactions = db.transactions || [];
  const tx = { id: Date.now(), type: 'exchange', userId, kot_amount: kotAmount, usdt_amount: usdt, rate, created_at: new Date().toISOString() };
  db.transactions.push(tx);

  try { writeDB(db); } catch(e){}

  return jsonResponse(res, { status:'ok', kot_amount: kotAmount, usdt_amount: usdt, rate });
};