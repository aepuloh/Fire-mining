// api/exchange.js
import { readDB, writeDB, jsonResponse, getBody, getUserIdFromReq } from './_utils.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return jsonResponse(res, { status: 'error', message: 'POST required' }, 405);
  }

  let userId = getUserIdFromReq(req);
  const body = await getBody(req);
  userId = userId || body.userId || body.user_id || body.telegram_id;

  if (!userId) {
    return jsonResponse(res, { status: 'error', message: 'userId required' }, 400);
  }

  const amount = Number(body.amount || 0);
  if (amount <= 0) {
    return jsonResponse(res, { status: 'error', message: 'Invalid amount' }, 400);
  }

  const db = readDB();
  db.users = db.users || {};
  if (!db.users[userId]) {
    return jsonResponse(res, { status: 'error', message: 'User not found' }, 404);
  }

  const user = db.users[userId];
  if (Number(user.kot_balance || 0) < amount) {
    return jsonResponse(res, { status: 'error', message: 'Insufficient KOT balance' }, 400);
  }

  // Tukar KOT ke USDT (rate 1:1)
  user.kot_balance -= amount;
  user.usdt_balance = (Number(user.usdt_balance) || 0) + amount;

  db.transactions = db.transactions || [];
  db.transactions.push({
    id: Date.now(),
    type: 'exchange',
    userId,
    amount_kot: amount,
    amount_usdt: amount,
    created_at: new Date().toISOString()
  });

  try { writeDB(db); } catch (e) { /* ignore */ }

  return jsonResponse(res, { status: 'ok', exchanged: amount });
}