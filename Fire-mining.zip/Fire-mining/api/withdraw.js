// api/withdraw.js
import { readDB, writeDB, jsonResponse, getBody, getUserIdFromReq } from './_utils.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return jsonResponse(res, { status: 'error', message: 'POST required' }, 405);
  }

  let userId = getUserIdFromReq(req);
  const body = await getBody(req);
  userId = userId || body.userId || body.user_id || body.telegram_id;

  if (!userId) {
    return jsonResponse(res, { status: 'error', message: 'userId required' }, 400);
  }

  const amount = Number(body.amount || 0);
  const wallet = body.wallet;

  if (!wallet) {
    return jsonResponse(res, { status: '