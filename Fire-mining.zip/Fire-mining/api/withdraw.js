// api/withdraw.js
const { readDB, writeDB, jsonResponse, getBody } = require('./_utils');

module.exports = async (req, res) => {
  if (req.method !== 'POST') return jsonResponse(res, { status:'error', message:'Use POST' }, 405);
  const body = await getBody(req);
  const userId = String(body.userId || body.user || '');
  const wallet = String(body.wallet || '');
  const amount = Number(body.amount_usdt || body.amount || 0);
  if (!userId || !wallet || amount <= 0) return jsonResponse(res, { status:'error', message:'userId, wallet, amount_usdt required' }, 400);

  const db = readDB();
  db.users = db.users || {};
  const user = db.users[userId];
  if (!user) return jsonResponse(res, { status:'error', message:'user not found' }, 404);

  if ((Number(user.usdt_balance || 0)) < amount) return jsonResponse(res, { status:'error', message:'insufficient USDT' }, 400);

  user.usdt_balance = Number(user.usdt_balance) - amount;

  db.transactions = db.transactions || [];
  const tx = { id: Date.now(), type: 'withdraw', userId, wallet, amount_usdt: amount, status: 'pending', created_at: new Date().toISOString() };
  db.transactions.push(tx);

  try { writeDB(db); } catch(e){}

  // NOTE: this endpoint only records the withdraw. To actually send USDT you must integrate with a wallet/exchange API.
  return jsonResponse(res, { status:'ok', tx });
};